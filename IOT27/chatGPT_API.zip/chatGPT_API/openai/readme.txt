PgP 3/27/2024
this is the original chatGPT python library created for IOT27
works well-at least to connect
make sure to put in chatGPT API key into chatgpt.txt file